#---- setup --------
wd <- dirname(dirname(rstudioapi::getActiveDocumentContext()$path))
dir.create(im_path <- file.path(wd, "R_images"), showWarnings = F)
options(im_path = im_path)

# change download method in case the firewall of your institute blocks the default method
# options(download.file.method = "wininet")
# change path where libraries are installed in case you are working on a virtual desktop
# .libPaths("your/desired/path")

# pak::pak("close-your-eyes/fcexpr")
# install.packages("ggplot2")
# install.packages("openxlsx")
# install.packages("purrr")
library(ggplot2)
library(fcexpr)

#---- synchronize fcs files and sampledescription --------
fcexpr::sync_sampledescription(file.path(wd, "FCS_files"))

# fcexpr::ab_info_to_panel(panel_file = file.path(wd, "Protocols", "ExpPart1.xlsx"), panel_sheet = "Panel")
# fcexpr::ab_panel_to_fcs(sampledescription = openxlsx::read.xlsx(file.path(wd, "sampledescription.xlsx")), FileNames = openxlsx::read.xlsx(file.path(wd, "sampledescription.xlsx")) %>% dplyr::filter(ExpPart == 1) %>% dplyr::pull(FileName), FCS.file.folder = file.path(wd, "FCS_files"), other_keywords = c("Isotype", "Clone", "totalDF", "Vendor", "Cat", "Lot"))

#---- flowjo wsp import --------
ws <- list.files(path = file.path(wd, "FJ_workspaces"), pattern = "wsp$", recursive = T, full.names = T)
ws
lst <- purrr::map(ws, fcexpr::wsx_get_popstats)
counts <- purrr::map_dfr(lst, "counts")

#---- sampledescription join --------
desc <- openxlsx::read.xlsx(file.path(wd, "sampledescription.xlsx"), detectDates = T)
desc <- desc[,colSums(is.na(desc))<nrow(desc)]
ps <- dplyr::left_join(counts, desc) #  by = dplyr::join_by(FileName, identity)


#---- wrangle data and plot --------





